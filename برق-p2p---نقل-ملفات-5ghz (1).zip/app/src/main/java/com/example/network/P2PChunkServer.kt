package com.example.network

import android.content.ContentResolver
import android.content.Context
import android.net.wifi.WifiManager
import com.example.model.ChunkSizeOption
import com.example.model.HotspotNetworkStatus
import com.example.model.TransferFileItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader
import java.io.RandomAccessFile
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Collections

/**
 * Local 5GHz Wi-Fi Hotspot P2P Server & Network Detector for "برق sher".
 * Serves:
 * - GET /                          -> Arabic RTL WebRTC (PeerJS) + LAN P2P Web Portal
 * - GET /api/manifest?code=...     -> JSON manifest of queued files (ONLY when isSenderReady == true and code matches)
 * - GET /api/chunk?fileId=...&chunkIndex=...&code=... -> Streams full binary chunk from sender's selected file/Uri
 */
class P2PChunkServer(
    private val context: Context,
    private val scope: CoroutineScope,
    private val sessionCodeProvider: () -> String,
    private val isSenderReadyProvider: () -> Boolean,
    private val chunkSizeProvider: () -> ChunkSizeOption,
    private val filesProvider: () -> List<TransferFileItem>,
    private val onChunkServed: (fileId: String, chunkIndex: Int, bytesCount: Int) -> Unit
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    var boundPort: Int = 8989
        private set

    fun startServer(): Int {
        if (serverJob?.isActive == true) return boundPort
        for (candidatePort in 8989..8999) {
            try {
                val ss = ServerSocket(candidatePort)
                ss.reuseAddress = true
                serverSocket = ss
                boundPort = candidatePort
                break
            } catch (_: Exception) {
                // try next port
            }
        }
        val activeSocket = serverSocket ?: return boundPort
        serverJob = scope.launch(Dispatchers.IO) {
            while (isActive && !activeSocket.isClosed) {
                try {
                    val client = activeSocket.accept()
                    launch(Dispatchers.IO) {
                        handleClient(client)
                    }
                } catch (_: Exception) {
                    if (!isActive) break
                }
            }
        }
        return boundPort
    }

    fun stopServer() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverJob?.cancel()
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 20_000
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val fullPath = parts[1]
            // Consume HTTP headers
            while (true) {
                val line = reader.readLine()
                if (line.isNullOrEmpty()) break
            }

            val out = BufferedOutputStream(client.getOutputStream())
            when {
                fullPath == "/" || fullPath.startsWith("/index") -> {
                    val net = inspectNetworkStatus(context, boundPort, true)
                    val htmlBytes = PeerJsWebPortalHtml.buildHtml(
                        defaultCode = sessionCodeProvider(),
                        hostIp = net.localIp,
                        hostPort = boundPort
                    ).toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "text/html; charset=utf-8", htmlBytes.size.toLong())
                    out.write(htmlBytes)
                    out.flush()
                }

                fullPath.startsWith("/api/manifest") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = params["code"]?.trim() ?: ""
                    val activeCode = sessionCodeProvider().trim()
                    val files = filesProvider()
                    val senderReady = isSenderReadyProvider()

                    if (!senderReady || files.isEmpty() || !requestedCode.equals(activeCode, ignoreCase = true)) {
                        val errJson = JSONObject().apply {
                            put("error", "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "application/json; charset=utf-8", errJson.size.toLong())
                        out.write(errJson)
                        out.flush()
                        return
                    }

                    val chunkBytes = chunkSizeProvider().bytes
                    val root = JSONObject()
                    root.put("sessionCode", activeCode)
                    root.put("chunkSize", chunkBytes)
                    val arr = JSONArray()
                    for (f in files) {
                        val obj = JSONObject()
                        obj.put("id", f.id)
                        obj.put("name", f.name)
                        obj.put("sizeBytes", f.sizeBytes)
                        obj.put("category", f.category.name)
                        obj.put("totalChunks", maxOf(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt()))
                        arr.put(obj)
                    }
                    root.put("files", arr)
                    val jsonBytes = root.toString().toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", jsonBytes.size.toLong())
                    out.write(jsonBytes)
                    out.flush()
                }

                fullPath.startsWith("/api/chunk") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = params["code"]?.trim() ?: ""
                    val activeCode = sessionCodeProvider().trim()
                    val senderReady = isSenderReadyProvider()

                    if (!senderReady || !requestedCode.equals(activeCode, ignoreCase = true)) {
                        val err = "Forbidden: Invalid code or sender not ready".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    val fileId = params["fileId"] ?: ""
                    val chunkIndex = params["chunkIndex"]?.toIntOrNull() ?: -1
                    val fileItem = filesProvider().find { it.id == fileId }
                    if (fileItem == null || chunkIndex < 0) {
                        val err = "File or chunk index not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    val chunkSize = chunkSizeProvider().bytes
                    val offset = chunkIndex.toLong() * chunkSize.toLong()
                    val remaining = (fileItem.sizeBytes - offset).coerceAtLeast(0L)
                    val bytesToRead = minOf(chunkSize.toLong(), remaining).toInt()

                    val buffer = readFileChunk(context.contentResolver, fileItem, offset, bytesToRead)
                    if (buffer == null) {
                        val err = "Failed to read file chunk from storage".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "500 Internal Server Error", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    writeHttpHeader(out, "200 OK", "application/octet-stream", buffer.size.toLong())
                    out.write(buffer)
                    out.flush()
                    onChunkServed(fileItem.id, chunkIndex, buffer.size)
                }

                fullPath.startsWith("/barq-p2p.apk") || fullPath.startsWith("/download-apk") -> {
                    val apkFile = File(context.applicationInfo.sourceDir)
                    if (apkFile.exists()) {
                        val header = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: application/vnd.android.package-archive\r\n")
                            append("Content-Disposition: attachment; filename=\"Barq-Sher.apk\"\r\n")
                            append("Content-Length: ${apkFile.length()}\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(StandardCharsets.UTF_8))
                        FileInputStream(apkFile).use { fis ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = fis.read(buf)
                                if (r == -1) break
                                out.write(buf, 0, r)
                            }
                        }
                        out.flush()
                    } else {
                        val err = "APK source not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain", err.size.toLong())
                        out.write(err)
                        out.flush()
                    }
                }

                else -> {
                    val msg = "Barq Sher 5GHz Endpoint".toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "404 Not Found", "text/plain", msg.size.toLong())
                    out.write(msg)
                    out.flush()
                }
            }
        }
    }

    private fun writeHttpHeader(
        out: BufferedOutputStream,
        status: String,
        contentType: String,
        contentLength: Long
    ) {
        val header = buildString {
            append("HTTP/1.1 $status\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(StandardCharsets.UTF_8))
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split("&").mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx <= 0) null
            else {
                val k = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
                val v = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                k to v
            }
        }.toMap()
    }

    companion object {
        /**
         * Reads the exact full chunk of [length] bytes at [offset] from the user-selected [TransferFileItem]
         * using ContentResolver or RandomAccessFile. Returns null if the source cannot be read.
         */
        fun readFileChunk(
            resolver: ContentResolver,
            item: TransferFileItem,
            offset: Long,
            length: Int
        ): ByteArray? {
            if (length < 0) return null
            if (length == 0) return ByteArray(0)

            // 1. If backed by a direct local File
            val localFile = item.localFile
            if (localFile != null && localFile.exists()) {
                return try {
                    RandomAccessFile(localFile, "r").use { raf ->
                        if (offset >= raf.length()) return ByteArray(0)
                        raf.seek(offset)
                        val maxReadable = minOf(length.toLong(), raf.length() - offset).toInt()
                        val buf = ByteArray(maxReadable)
                        var totalRead = 0
                        while (totalRead < maxReadable) {
                            val r = raf.read(buf, totalRead, maxReadable - totalRead)
                            if (r == -1) break
                            totalRead += r
                        }
                        if (totalRead == buf.size) buf else buf.copyOf(totalRead)
                    }
                } catch (_: IOException) {
                    null
                }
            }

            // 2. If backed by a Content Uri selected via ContentResolver
            val uri = item.uri ?: return null
            // Try fast seekable ParcelFileDescriptor channel first
            try {
                resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    FileInputStream(pfd.fileDescriptor).use { fis ->
                        val channel = fis.channel
                        channel.position(offset)
                        val buf = ByteArray(length)
                        val byteBuffer = ByteBuffer.wrap(buf)
                        var totalRead = 0
                        while (totalRead < length) {
                            val r = channel.read(byteBuffer)
                            if (r <= 0) break
                            totalRead += r
                        }
                        if (totalRead > 0) {
                            return if (totalRead == length) buf else buf.copyOf(totalRead)
                        }
                    }
                }
            } catch (_: Exception) {
                // Fallback to sequential InputStream if provider does not support channel seek
            }

            return try {
                val input = resolver.openInputStream(uri) ?: return null
                input.use { stream ->
                    var remainingToSkip = offset
                    val skipScratch = ByteArray(minOf(64 * 1024L, maxOf(1L, remainingToSkip)).toInt())
                    while (remainingToSkip > 0) {
                        val skipped = stream.skip(remainingToSkip)
                        if (skipped > 0) {
                            remainingToSkip -= skipped
                        } else {
                            val toReadSkip = minOf(skipScratch.size.toLong(), remainingToSkip).toInt()
                            val readCount = stream.read(skipScratch, 0, toReadSkip)
                            if (readCount == -1) return ByteArray(0)
                            remainingToSkip -= readCount
                        }
                    }

                    val result = ByteArray(length)
                    var totalRead = 0
                    while (totalRead < length) {
                        val r = stream.read(result, totalRead, length - totalRead)
                        if (r == -1) break
                        totalRead += r
                    }
                    if (totalRead == 0) null
                    else if (totalRead == length) result
                    else result.copyOf(totalRead)
                }
            } catch (_: Exception) {
                null
            }
        }

        fun inspectNetworkStatus(
            context: Context,
            port: Int,
            isServerRunning: Boolean
        ): HotspotNetworkStatus {
            var detectedIp = "192.168.43.1"
            var ifaceName = "wlan0 (Hotspot)"
            try {
                val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (ni in interfaces) {
                    if (!ni.isUp || ni.isLoopback) continue
                    val addrs = Collections.list(ni.inetAddresses)
                    for (addr in addrs) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            val ip = addr.hostAddress ?: continue
                            detectedIp = ip
                            ifaceName = ni.displayName ?: ni.name ?: "wlan0"
                            if (ip.startsWith("192.168.") || ip.startsWith("172.") || ip.startsWith("10.")) {
                                break
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }

            var freq = 5180
            var linkSpeed = 866
            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                @Suppress("DEPRECATION")
                val info = wm?.connectionInfo
                if (info != null) {
                    if (info.frequency > 0) freq = info.frequency
                    if (info.linkSpeed > 0) linkSpeed = info.linkSpeed
                }
            } catch (_: Exception) {
            }

            val is5G = freq >= 4900
            return HotspotNetworkStatus(
                localIp = detectedIp,
                port = port,
                is5GHzBand = is5G,
                frequencyMHz = freq,
                linkSpeedMbps = linkSpeed,
                ssidOrInterface = ifaceName,
                isServerRunning = isServerRunning
            )
        }
    }
}
