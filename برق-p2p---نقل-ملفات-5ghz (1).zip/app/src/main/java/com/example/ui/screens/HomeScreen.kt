package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppScreen
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.Hotspot5GHzInstructionBanner
import com.example.ui.components.P2PRadarWaveIllustration
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightCardElevated
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: P2PUiState,
    onNavigate: (AppScreen) -> Unit,
    onRefreshNetwork: () -> Unit,
    onShowHotspotGuide: (Boolean) -> Unit,
    onExportApk: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // App Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(ElectricCyan.copy(alpha = 0.25f), NeonEmerald.copy(alpha = 0.25f))
                                )
                            )
                            .border(1.dp, ElectricCyan.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = "شعار برق sher",
                            tint = ElectricCyan,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "برق sher",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                        Text(
                            text = "نقل مباشر عبر نقطة اتصال 5GHz ودفعات Chunking",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onRefreshNetwork,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, CircleShape)
                        .testTag("refresh_network_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "تحديث حالة الشبكة",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Top Instructional Alert Banner for 5GHz Wi-Fi Hotspot
            Hotspot5GHzInstructionBanner(
                networkStatus = uiState.networkStatus,
                onShowDetailsClick = { onShowHotspotGuide(true) }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Animated 5GHz P2P Radar & Chunk Stream Illustration
            P2PRadarWaveIllustration()

            Spacer(modifier = Modifier.height(18.dp))

            // Main Screen Split Clearly into Two Options: "إرسال ملفات" & "استلام ملفات"
            Text(
                text = "اختر وضع النقل المباشر (P2P)",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            // Primary Option 1: Send Files Card
            PrimaryModeSplitCard(
                title = "إرسال ملفات",
                subtitle = "توليد كود اتصال قصير (${uiState.connectionCode}) مع رمز QR Code واختيار عدة ملفات دفعة واحدة (صور، فيديوهات، ألعاب APK، ومستندات) بأي حجم.",
                badgeText = "المرسل • توليد QR + كود",
                accentColor = ElectricCyan,
                mainIcon = Icons.Filled.CloudUpload,
                secondaryIcon = Icons.Filled.QrCode2,
                tags = listOf("صور RAW", "فيديوهات 4K/8K", "ألعاب APK/OBB", "ملفات مضغوطة ZIP"),
                testTag = "home_send_files_card",
                onClick = { onNavigate(AppScreen.SEND) }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Primary Option 2: Receive Files Card
            PrimaryModeSplitCard(
                title = "استلام ملفات",
                subtitle = "إدخال كود الاتصال القصير أو مسح رمز QR بالكاميرا للربط الفوري مع الجوال المرسل وتأكيد وتحميل الملفات المستلمة مباشرة إلى جهازك.",
                badgeText = "المستلم • مسح QR أو كود",
                accentColor = NeonEmerald,
                mainIcon = Icons.Filled.CloudDownload,
                secondaryIcon = Icons.Filled.QrCodeScanner,
                tags = listOf("ربط فوري P2P", "تأكيد قبل التحميل", "تجميع دفعات Chunks", "سرعة 5GHz القصوى"),
                testTag = "home_receive_files_card",
                onClick = { onNavigate(AppScreen.RECEIVE) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // WebRTC (PeerJS) Browser Portal Button
            OutlinedButton(
                onClick = { onNavigate(AppScreen.WEBRTC_PORTAL) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("webrtc_portal_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Language,
                    contentDescription = null,
                    tint = NeonEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "بوابة الويب المحلية (PeerJS WebRTC)",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Direct APK Download & Extraction Card
            Button(
                onClick = onExportApk,
                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("export_self_apk_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudDownload,
                    contentDescription = null,
                    tint = Color(0xFF1F1200)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "استخراج وتنزيل ملف التطبيق (Barq-Sher.apk)",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF1F1200),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Technical Specs Footer Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MidnightCard)
                    .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.ViewModule,
                            contentDescription = null,
                            tint = HotspotAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "نظام تقسيم الدفعات الذكي (Smart Chunking)",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White
                            )
                            Text(
                                text = "حجم الدفعة الحالي: ${uiState.selectedChunkSize.label} لمنع انقطاع الفيديوهات والألعاب",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                    }
                    Text(
                        text = uiState.connectionCode,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyan,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // Fixed Copyright Footer at the bottom of HomeScreen
        CopyrightFooter()
    }

    if (uiState.showHotspotGuideSheet) {
        ModalBottomSheet(
            onDismissRequest = { onShowHotspotGuide(false) },
            containerColor = MidnightCardElevated
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "خطوات تفعيل نقطة اتصال 5GHz في برق sher",
                    style = MaterialTheme.typography.titleLarge,
                    color = HotspotAmber
                )
                Spacer(modifier = Modifier.height(12.dp))
                GuideStepItem(
                    number = "1",
                    title = "في الجوال الأول (نقطة الاتصال):",
                    desc = "افتح الإعدادات ← نقطة الاتصال الهواتف المحمولة (Wi-Fi Hotspot) ← اختر النطاق الترددي 5GHz بدلاً من 2.4GHz."
                )
                GuideStepItem(
                    number = "2",
                    title = "في الجوال الثاني (المتصل):",
                    desc = "اتصل بشبكة الـ Wi-Fi الخاصة بالجوال الأول (النقل يتم محلياً بنسبة 100% بدون إنترنت)."
                )
                GuideStepItem(
                    number = "3",
                    title = "اختر الملفات واضغط بدء الإرسال:",
                    desc = "في جوال المرسل اختر ملفاتك واضغط (بدء الإرسال)، ثم في جوال المستلم أدخل الكود أو امسح رمز QR وأكّد استلام الملفات."
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { onShowHotspotGuide(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("فهمت، إغلاق الدليل", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PrimaryModeSplitCard(
    title: String,
    subtitle: String,
    badgeText: String,
    accentColor: Color,
    mainIcon: ImageVector,
    secondaryIcon: ImageVector,
    tags: List<String>,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        accentColor.copy(alpha = 0.16f),
                        MidnightCard,
                        Color(0xFF0B1324)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(
                    listOf(accentColor.copy(alpha = 0.85f), GlassBorder)
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .clickable(onClick = onClick)
            .padding(20.dp)
            .testTag(testTag)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(accentColor.copy(alpha = 0.18f))
                            .border(1.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    ) {
                        Icon(
                            imageVector = mainIcon,
                            contentDescription = title,
                            tint = accentColor,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Surface(
                            color = accentColor.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelMedium,
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.06f))
                ) {
                    Icon(
                        imageVector = secondaryIcon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD5E1)
            )

            Spacer(modifier = Modifier.height(14.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tags.forEach { tag ->
                    Surface(
                        color = Color(0xFF09101E),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = tag,
                            style = MaterialTheme.typography.labelMedium,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideStepItem(number: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(ElectricCyan.copy(alpha = 0.2f))
        ) {
            Text(
                text = number,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                color = ElectricCyan
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
    }
}
