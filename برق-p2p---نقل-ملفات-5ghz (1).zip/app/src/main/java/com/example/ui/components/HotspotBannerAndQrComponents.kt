package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileCategory
import com.example.model.HotspotNetworkStatus
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.util.QrCodeGenerator
import java.util.Locale

/**
 * Fixed and clearly visible copyright footer displayed at the bottom of screens.
 */
@Composable
fun CopyrightFooter(
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightSurface)
            .border(width = 0.5.dp, color = GlassBorder)
            .padding(vertical = 10.dp, horizontal = 16.dp)
            .testTag("copyright_footer")
    ) {
        Text(
            text = "جميع الحقوق محفوظة © saeed",
            style = MaterialTheme.typography.labelLarge,
            color = ElectricCyan,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Prominent top instructional alert explaining how to enable 5GHz Wi-Fi Hotspot
 * on the first phone and connect from the second phone for maximum P2P speed.
 */
@Composable
fun Hotspot5GHzInstructionBanner(
    networkStatus: HotspotNetworkStatus,
    onShowDetailsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hotspot_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF2B1E0B),
                        Color(0xFF0E1D34),
                        Color(0xFF092230)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        HotspotAmber.copy(alpha = 0.85f),
                        ElectricCyan.copy(alpha = 0.65f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onShowDetailsClick() }
            .padding(16.dp)
            .testTag("hotspot_instruction_banner")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(HotspotAmber.copy(alpha = 0.18f))
                            .border(1.dp, HotspotAmber.copy(alpha = pulseAlpha), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WifiTethering,
                            contentDescription = "نقطة اتصال 5GHz",
                            tint = HotspotAmber,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "تنبيه التشغيل للسرعة القصوى",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = HotspotAmber,
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = "5GHz Hotspot",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFF1F1200),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "نقل مباشر من جهاز لجهاز (P2P WebRTC) بدون إنترنت",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "تفاصيل إعداد نقطة الاتصال",
                    tint = HotspotAmber,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "شغّل نقطة اتصال (Wi-Fi Hotspot 5GHz) في الجوال الأول، واتصل بها من الجوال الثاني لتحصل على أقصى سرعة نقل مباشر للملفات والألعاب الكبيرة.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NeonEmerald)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "IP المحلي: ${networkStatus.localIp}:${networkStatus.port}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = NeonEmerald
                    )
                }

                Text(
                    text = "اضغط لعرض خطوات الضبط ←",
                    style = MaterialTheme.typography.labelMedium,
                    color = HotspotAmber,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Renders an authentic ISO 18004 QR Code on a Compose Canvas.
 */
@Composable
fun QrCodeCanvas(
    content: String,
    size: Dp = 210.dp,
    modifier: Modifier = Modifier
) {
    val matrix = remember(content) {
        QrCodeGenerator.encodeToMatrix(content)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .border(3.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(22.dp))
            .padding(14.dp)
            .testTag("qr_code_canvas")
    ) {
        Canvas(modifier = Modifier.size(size - 28.dp)) {
            val moduleCount = matrix.size
            if (moduleCount == 0) return@Canvas
            val cellSize = this.size.width / moduleCount.toFloat()

            for (r in 0 until moduleCount) {
                for (c in 0 until moduleCount) {
                    if (matrix[r][c]) {
                        val isFinderCorner =
                            (r < 7 && c < 7) ||
                                (r < 7 && c >= moduleCount - 7) ||
                                (r >= moduleCount - 7 && c < 7)
                        drawRoundRect(
                            color = if (isFinderCorner) Color(0xFF06152D) else Color(0xFF0A192F),
                            topLeft = Offset(c * cellSize, r * cellSize),
                            size = Size(cellSize * 1.03f, cellSize * 1.03f),
                            cornerRadius = CornerRadius(cellSize * 0.2f, cellSize * 0.2f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Animated 5GHz P2P Dual-Phone Signal Header Graphic
 */
@Composable
fun P2PRadarWaveIllustration(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "radar_wave")
    val waveProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_progress"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val cy = size.height / 2f
            val rightX = size.width * 0.82f
            val leftX = size.width * 0.18f

            drawLine(
                brush = Brush.horizontalGradient(
                    colors = listOf(NeonEmerald.copy(alpha = 0.4f), ElectricCyan.copy(alpha = 0.4f))
                ),
                start = Offset(leftX, cy),
                end = Offset(rightX, cy),
                strokeWidth = 4.dp.toPx()
            )

            for (i in 0..3) {
                val p = ((waveProgress + i * 0.25f) % 1f)
                val packetX = rightX - (rightX - leftX) * p
                drawCircle(
                    color = if (i % 2 == 0) ElectricCyan else NeonEmerald,
                    radius = 5.dp.toPx(),
                    center = Offset(packetX, cy)
                )
            }

            val maxRadius = 34.dp.toPx()
            drawCircle(
                color = ElectricCyan.copy(alpha = (1f - waveProgress) * 0.45f),
                radius = maxRadius * waveProgress,
                center = Offset(rightX, cy),
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = NeonEmerald.copy(alpha = (1f - waveProgress) * 0.45f),
                radius = maxRadius * waveProgress,
                center = Offset(leftX, cy),
                style = Stroke(width = 2.dp.toPx())
            )

            drawCircle(color = ElectricCyan, radius = 9.dp.toPx(), center = Offset(rightX, cy))
            drawCircle(color = NeonEmerald, radius = 9.dp.toPx(), center = Offset(leftX, cy))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = "الجوال الأول (نقطة اتصال 5GHz)",
                style = MaterialTheme.typography.labelMedium,
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "برق sher • P2P",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 11.sp,
                color = TextSecondary
            )
            Text(
                text = "الجوال الثاني (المستلم P2P)",
                style = MaterialTheme.typography.labelMedium,
                color = NeonEmerald,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

fun categoryIcon(category: FileCategory): ImageVector = when (category) {
    FileCategory.VIDEO -> Icons.Filled.Movie
    FileCategory.IMAGE -> Icons.Filled.Image
    FileCategory.GAME_APK -> Icons.Filled.Android
    FileCategory.ARCHIVE -> Icons.Filled.FolderZip
    FileCategory.DOCUMENT -> Icons.Filled.Description
}

fun formatBytesArabic(bytes: Long): String {
    if (bytes <= 0L) return "0 KB"
    val gb = 1024.0 * 1024.0 * 1024.0
    val mb = 1024.0 * 1024.0
    val kb = 1024.0
    return when {
        bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
        bytes >= mb -> String.format(Locale.US, "%.2f MB", bytes / mb)
        else -> String.format(Locale.US, "%.1f KB", bytes / kb)
    }
}
