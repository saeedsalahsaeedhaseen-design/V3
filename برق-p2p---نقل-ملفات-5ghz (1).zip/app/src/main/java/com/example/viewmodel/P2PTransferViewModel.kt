package com.example.viewmodel

import android.app.Application
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppScreen
import com.example.model.ChunkSizeOption
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.HotspotNetworkStatus
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.network.P2PChunkServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.random.Random

data class P2PUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val networkStatus: HotspotNetworkStatus = HotspotNetworkStatus(),
    val connectionCode: String = "5G-4829",
    val enteredReceiveCode: String = "",
    val isSenderReady: Boolean = false,
    val remoteHostIp: String = "",
    val remoteHostPort: Int = 8989,
    val remoteSessionCode: String = "",
    val remoteChunkSizeBytes: Int = ChunkSizeOption.CHUNK_1MB.bytes,
    val pendingIncomingFiles: List<TransferFileItem> = emptyList(),
    val showReceiveConfirmationDialog: Boolean = false,
    val isConnectingToSender: Boolean = false,
    val peerJsStatusText: String = "WebRTC PeerJS + 5GHz P2P نشط",
    val selectedChunkSize: ChunkSizeOption = ChunkSizeOption.CHUNK_1MB,
    val transferDirection: TransferDirection = TransferDirection.SENDING,
    val files: List<TransferFileItem> = emptyList(),
    val isTransferRunning: Boolean = false,
    val isPaused: Boolean = false,
    val liveOverallSpeedMbps: Double = 0.0,
    val peakSpeedMbps: Double = 0.0,
    val statusBannerMessage: String? = null,
    val showHotspotGuideSheet: Boolean = false,
    val connectedPeerLabel: String = "بانتظار اتصال الجوال الثاني..."
) {
    val totalBytes: Long
        get() = files.sumOf { it.sizeBytes }

    val transferredBytes: Long
        get() = files.sumOf { it.transferredBytes }

    val overallProgressFraction: Float
        get() = if (totalBytes <= 0L) 0f else (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)

    val totalChunksCount: Int
        get() = files.sumOf { it.totalChunks }

    val completedChunksCount: Int
        get() = files.sumOf { it.completedChunks }

    val pendingTotalBytes: Long
        get() = pendingIncomingFiles.sumOf { it.sizeBytes }

    val qrPayload: String
        get() = "BARQP2P|$connectionCode|${networkStatus.localIp}|${networkStatus.port}"
}

class P2PTransferViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(P2PUiState())
    val uiState: StateFlow<P2PUiState> = _uiState.asStateFlow()

    private var chunkServer: P2PChunkServer? = null
    private var activeTransferJob: Job? = null
    private val senderFileStartNanoMap = ConcurrentHashMap<String, Long>()
    private val senderFileServedBytesMap = ConcurrentHashMap<String, Long>()

    init {
        startLocalP2PServerAndInspectNetwork()
    }

    private fun startLocalP2PServerAndInspectNetwork() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val server = P2PChunkServer(
                context = appContext,
                scope = viewModelScope,
                sessionCodeProvider = { _uiState.value.connectionCode },
                isSenderReadyProvider = { _uiState.value.isSenderReady },
                chunkSizeProvider = { _uiState.value.selectedChunkSize },
                filesProvider = { _uiState.value.files },
                onChunkServed = { fileId, chunkIdx, bytesCount ->
                    onRemotePeerPulledChunk(fileId, chunkIdx, bytesCount)
                }
            )
            val port = server.startServer()
            chunkServer = server
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val initialCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = initialCode,
                    enteredReceiveCode = "" // Always leave receive code empty until user enters or scans
                )
            }
        }
    }

    private fun buildShortCodeFromIp(ip: String): String {
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: Random.nextInt(10, 99)
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val suffix = String.format(Locale.US, "%02d%02d", thirdOctet % 100, lastOctet % 100)
        return "5G-$suffix"
    }

    fun refreshNetworkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val port = chunkServer?.boundPort ?: 8989
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    statusBannerMessage = "تم تحديث حالة الشبكة: ${net.localIp}:${net.port} (${if (net.is5GHzBand) "نطاق 5GHz فائق السرعة" else "نطاق 2.4GHz"})"
                )
            }
        }
    }

    fun regenerateConnectionCode() {
        val ip = _uiState.value.networkStatus.localIp
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: 1
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val newCode = String.format(Locale.US, "5G-%02d%02d", thirdOctet % 100, lastOctet % 100)
        _uiState.update {
            it.copy(
                connectionCode = newCode,
                statusBannerMessage = "تم تحديث كود الاتصال المباشر: $newCode"
            )
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.LIVE_TRANSFER && _uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال")
            }
            return
        }
        _uiState.update { it.copy(currentScreen = screen, statusBannerMessage = null) }
    }

    fun toggleHotspotGuideSheet(show: Boolean) {
        _uiState.update { it.copy(showHotspotGuideSheet = show) }
    }

    fun setChunkSize(option: ChunkSizeOption) {
        _uiState.update { state ->
            val updatedFiles = state.files.map { file ->
                val newTotalChunks = max(1, ((file.sizeBytes + option.bytes - 1) / option.bytes).toInt())
                file.copy(
                    totalChunks = newTotalChunks,
                    completedChunks = if (file.status == FileTransferStatus.COMPLETED) newTotalChunks else 0,
                    transferredBytes = if (file.status == FileTransferStatus.COMPLETED) file.sizeBytes else 0L
                )
            }
            state.copy(
                selectedChunkSize = option,
                files = updatedFiles,
                statusBannerMessage = "تم ضبط حجم الدفعة (Chunk Size) إلى ${option.label}"
            )
        }
    }

    fun updateEnteredReceiveCode(code: String) {
        _uiState.update { it.copy(enteredReceiveCode = code.uppercase(Locale.US)) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun addPickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val appContext = getApplication<Application>().applicationContext
        val resolver = appContext.contentResolver
        val chunkBytes = _uiState.value.selectedChunkSize.bytes

        val addedItems = uris.mapNotNull { uri ->
            var displayName = "ملف_مرسل_${System.currentTimeMillis() % 10000}"
            var sizeBytes = 0L
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) {
                            displayName = cursor.getString(nameIdx) ?: displayName
                        }
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            sizeBytes = cursor.getLong(sizeIdx)
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (sizeBytes <= 0L) {
                try {
                    resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        if (afd.length > 0) sizeBytes = afd.length
                    }
                } catch (_: Exception) {
                }
            }
            if (sizeBytes <= 0L) return@mapNotNull null

            val mime = resolver.getType(uri)
            val category = FileCategory.fromFileName(displayName, mime)
            val totalChunks = max(1, ((sizeBytes + chunkBytes - 1) / chunkBytes).toInt())

            TransferFileItem(
                id = UUID.randomUUID().toString().take(8),
                name = displayName,
                sizeBytes = sizeBytes,
                category = category,
                uri = uri,
                totalChunks = totalChunks,
                checksumPreview = computeQuickTag(displayName, sizeBytes)
            )
        }

        if (addedItems.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر قراءة حجم الملف المحدد، يرجى اختيار ملف صالح من الجهاز")
            }
            return
        }

        _uiState.update { state ->
            state.copy(
                files = state.files + addedItems,
                isSenderReady = false,
                transferDirection = TransferDirection.SENDING,
                statusBannerMessage = "تمت إضافة ${addedItems.size} ملفات. اضغط (بدء الإرسال) لتفعيل الربط للجوال المستلم."
            )
        }
    }

    fun removeFileItem(fileId: String) {
        _uiState.update { state ->
            val remaining = state.files.filterNot { it.id == fileId }
            state.copy(
                files = remaining,
                isSenderReady = if (remaining.isEmpty()) false else state.isSenderReady
            )
        }
    }

    fun clearAllFiles() {
        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        _uiState.update {
            it.copy(
                files = emptyList(),
                isSenderReady = false,
                isTransferRunning = false,
                isPaused = false,
                liveOverallSpeedMbps = 0.0
            )
        }
    }

    /**
     * Updates the Sender's live transfer screen in real time when the Receiver device
     * pulls each chunk over the network via P2PChunkServer.
     */
    private fun onRemotePeerPulledChunk(fileId: String, chunkIdx: Int, bytesCount: Int) {
        val nowNano = System.nanoTime()
        val startNano = senderFileStartNanoMap.getOrPut(fileId) { nowNano }
        val totalServedForFile = (senderFileServedBytesMap[fileId] ?: 0L) + bytesCount.toLong()
        senderFileServedBytesMap[fileId] = totalServedForFile

        val elapsedSec = max(0.005, (nowNano - startNano) / 1_000_000_000.0)
        val realSpeedMbps = (totalServedForFile / (1024.0 * 1024.0)) / elapsedSec

        _uiState.update { state ->
            val updated = state.files.map { item ->
                if (item.id != fileId) item
                else {
                    val newCompleted = max(item.completedChunks, chunkIdx + 1).coerceAtMost(item.totalChunks)
                    val newBytes = minOf(item.sizeBytes, totalServedForFile)
                    val isDone = newCompleted >= item.totalChunks || newBytes >= item.sizeBytes
                    item.copy(
                        completedChunks = newCompleted,
                        transferredBytes = if (isDone) item.sizeBytes else newBytes,
                        status = if (isDone) FileTransferStatus.COMPLETED else FileTransferStatus.TRANSFERRING,
                        currentSpeedMbps = realSpeedMbps
                    )
                }
            }
            val allCompleted = updated.isNotEmpty() && updated.all { it.status == FileTransferStatus.COMPLETED }
            state.copy(
                files = updated,
                isTransferRunning = !allCompleted,
                connectedPeerLabel = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات للمستلم بنجاح"
                } else {
                    "متصل بالجوال المستلم • جاري سحب الدفعات عبر الشبكة"
                },
                liveOverallSpeedMbps = if (allCompleted) 0.0 else realSpeedMbps,
                peakSpeedMbps = max(state.peakSpeedMbps, realSpeedMbps),
                statusBannerMessage = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات إلى الجوال المستلم بنجاح!"
                } else {
                    state.statusBannerMessage
                }
            )
        }
    }

    /**
     * Starts either:
     * - SENDING mode: validates files are selected, sets isSenderReady = true, and waits for the receiver
     *   to pull chunks over HTTP (updating progress live via onRemotePeerPulledChunk).
     * - RECEIVING mode: after user confirmation, pulls each chunk over HTTP from remoteHostIp:remoteHostPort
     *   and writes the full bytes to Downloads/BarqSher.
     */
    fun startLiveChunkedTransfer(direction: TransferDirection) {
        if (_uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال"
                )
            }
            return
        }

        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()

        if (direction == TransferDirection.SENDING) {
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            _uiState.update { state ->
                val resetFiles = state.files.map { f ->
                    val totalChunks = max(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
                    f.copy(
                        totalChunks = totalChunks,
                        completedChunks = 0,
                        transferredBytes = 0L,
                        currentSpeedMbps = 0.0,
                        status = FileTransferStatus.QUEUED
                    )
                }
                state.copy(
                    currentScreen = AppScreen.LIVE_TRANSFER,
                    transferDirection = TransferDirection.SENDING,
                    isSenderReady = true,
                    files = resetFiles,
                    isTransferRunning = true,
                    isPaused = false,
                    liveOverallSpeedMbps = 0.0,
                    connectedPeerLabel = "بانتظار اتصال الجوال المستلم بالكود (${state.connectionCode})...",
                    statusBannerMessage = "تم تفعيل وضع الإرسال! أدخل الكود (${state.connectionCode}) أو امسح رمز QR من الجوال الثاني للبدء."
                )
            }
            return
        }

        // RECEIVING direction: pull real chunks over network from remoteHostIp:remoteHostPort
        _uiState.update { state ->
            val resetFiles = state.files.map {
                it.copy(
                    completedChunks = 0,
                    transferredBytes = 0L,
                    currentSpeedMbps = 0.0,
                    status = FileTransferStatus.QUEUED
                )
            }
            state.copy(
                currentScreen = AppScreen.LIVE_TRANSFER,
                transferDirection = TransferDirection.RECEIVING,
                files = resetFiles,
                isTransferRunning = true,
                isPaused = false,
                liveOverallSpeedMbps = 0.0,
                connectedPeerLabel = "متصل بالمرسل (${state.remoteHostIp}:${state.remoteHostPort} • ${state.remoteSessionCode})"
            )
        }

        activeTransferJob = viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val hostIp = _uiState.value.remoteHostIp
            val hostPort = _uiState.value.remoteHostPort
            val sessionCode = _uiState.value.remoteSessionCode

            val downloadDir = resolveBarqSherDownloadsDir(appContext)
            val fileIds = _uiState.value.files.map { it.id }
            var anyFailed = false

            for (fileId in fileIds) {
                if (!isActive) break
                val initialItem = _uiState.value.files.find { it.id == fileId } ?: continue
                val totalChunks = max(1, initialItem.totalChunks)
                val outFile = File(downloadDir, initialItem.name)

                updateFileState(fileId) {
                    it.copy(status = FileTransferStatus.TRANSFERRING)
                }

                var transferredForFile = 0L
                val fileStartNano = System.nanoTime()

                try {
                    FileOutputStream(outFile).use { fos ->
                        val ioBuffer = ByteArray(64 * 1024)
                        for (chunkIndex in 0 until totalChunks) {
                            while (_uiState.value.isPaused && isActive) {
                                delay(120)
                            }
                            if (!isActive) break

                            val encodedFileId = URLEncoder.encode(initialItem.id, "UTF-8")
                            val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                            val chunkUrl = URL(
                                "http://$hostIp:$hostPort/api/chunk?fileId=$encodedFileId&chunkIndex=$chunkIndex&code=$encodedCode"
                            )
                            val conn = (chunkUrl.openConnection() as HttpURLConnection).apply {
                                connectTimeout = 8_000
                                readTimeout = 15_000
                                requestMethod = "GET"
                            }

                            val responseCode = conn.responseCode
                            if (responseCode != 200) {
                                conn.disconnect()
                                throw IllegalStateException("HTTP $responseCode while fetching chunk $chunkIndex")
                            }

                            var chunkBytesReceived = 0L
                            BufferedInputStream(conn.inputStream).use { input ->
                                while (true) {
                                    val readCount = input.read(ioBuffer)
                                    if (readCount == -1) break
                                    fos.write(ioBuffer, 0, readCount)
                                    chunkBytesReceived += readCount
                                }
                            }
                            conn.disconnect()

                            transferredForFile += chunkBytesReceived
                            val elapsedSec = max(0.005, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                            val realSpeedMbps = (transferredForFile / (1024.0 * 1024.0)) / elapsedSec

                            val doneChunks = chunkIndex + 1
                            val isComplete = doneChunks >= totalChunks

                            _uiState.update { state ->
                                val updatedFiles = state.files.map { f ->
                                    if (f.id != fileId) f
                                    else f.copy(
                                        completedChunks = doneChunks,
                                        transferredBytes = if (isComplete) max(f.sizeBytes, transferredForFile) else transferredForFile,
                                        currentSpeedMbps = realSpeedMbps,
                                        status = if (isComplete) FileTransferStatus.COMPLETED else FileTransferStatus.TRANSFERRING,
                                        savedPath = if (isComplete) outFile.absolutePath else null
                                    )
                                }
                                state.copy(
                                    files = updatedFiles,
                                    liveOverallSpeedMbps = realSpeedMbps,
                                    peakSpeedMbps = max(state.peakSpeedMbps, realSpeedMbps)
                                )
                            }
                        }
                        fos.flush()
                    }
                } catch (_: Exception) {
                    anyFailed = true
                    updateFileState(fileId) {
                        it.copy(status = FileTransferStatus.FAILED, currentSpeedMbps = 0.0)
                    }
                    break
                }
            }

            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        isTransferRunning = false,
                        liveOverallSpeedMbps = 0.0,
                        statusBannerMessage = if (anyFailed) {
                            "انقطع الاتصال بالمرسل أثناء تحميل الدفعات. تأكد من استمرار اتصال شبكة 5GHz."
                        } else {
                            "اكتمل استلام وحفظ جميع الملفات في مجلد التنزيلات (Downloads/BarqSher) بنجاح!"
                        }
                    )
                }
            }
        }
    }

    private fun resolveBarqSherDownloadsDir(appContext: android.content.Context): File {
        return try {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val barqDir = File(publicDownloads, "BarqSher")
            if (barqDir.exists() || barqDir.mkdirs()) {
                barqDir
            } else {
                File(
                    appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                    "BarqSher"
                ).apply { mkdirs() }
            }
        } catch (_: Exception) {
            File(
                appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                "BarqSher"
            ).apply { mkdirs() }
        }
    }

    /**
     * Connects to the sender's P2PChunkServer to verify the session code and sender readiness,
     * and retrieves the incoming file manifest so the user can confirm before any chunk transfer starts.
     */
    fun connectAndReceiveFromInput(rawInput: String) {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                )
            }
            return
        }

        _uiState.update { it.copy(isConnectingToSender = true, statusBannerMessage = null) }

        viewModelScope.launch(Dispatchers.IO) {
            var targetIp: String? = null
            var targetPort = _uiState.value.networkStatus.port
            var sessionCode = ""

            if (cleaned.startsWith("BARQP2P|", ignoreCase = true)) {
                val tokens = cleaned.split("|")
                if (tokens.size >= 4) {
                    sessionCode = tokens[1].trim().uppercase(Locale.US)
                    targetIp = tokens[2].trim()
                    targetPort = tokens[3].trim().toIntOrNull() ?: targetPort
                }
            } else {
                // Strict validation of short code format: e.g. 5G-XXXX (or IP:port#code)
                val normalized = cleaned.uppercase(Locale.US)
                val shortCodeRegex = Regex("^5G-(\\d{2})(\\d{2})$")
                val match = shortCodeRegex.matchEntire(normalized)
                if (match != null) {
                    sessionCode = normalized
                    val thirdOctet = match.groupValues[1].toIntOrNull()
                    val fourthOctet = match.groupValues[2].toIntOrNull()
                    val myIpParts = _uiState.value.networkStatus.localIp.split(".")
                    if (myIpParts.size == 4 && thirdOctet != null && fourthOctet != null) {
                        targetIp = "${myIpParts[0]}.${myIpParts[1]}.$thirdOctet.$fourthOctet"
                    }
                }
            }

            if (targetIp.isNullOrBlank() || sessionCode.isBlank()) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                }
                return@launch
            }

            var fetchedRemoteFiles: List<TransferFileItem>? = null
            var remoteChunkSize = _uiState.value.selectedChunkSize.bytes

            try {
                val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                val url = URL("http://$targetIp:$targetPort/api/manifest?code=$encodedCode")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 4500
                    requestMethod = "GET"
                }
                if (conn.responseCode == 200) {
                    val body = BufferedInputStream(conn.inputStream).bufferedReader().readText()
                    val json = JSONObject(body)
                    remoteChunkSize = json.optInt("chunkSize", remoteChunkSize)
                    val arr = json.optJSONArray("files")
                    if (arr != null && arr.length() > 0) {
                        val list = mutableListOf<TransferFileItem>()
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val name = o.optString("name", "file_$i")
                            val size = o.optLong("sizeBytes", 0L)
                            val chunks = max(1, o.optInt("totalChunks", 1))
                            if (size > 0L) {
                                list.add(
                                    TransferFileItem(
                                        id = o.optString("id", "rem_$i"),
                                        name = name,
                                        sizeBytes = size,
                                        category = FileCategory.fromFileName(name),
                                        totalChunks = chunks,
                                        checksumPreview = computeQuickTag(name, size)
                                    )
                                )
                            }
                        }
                        if (list.isNotEmpty()) {
                            fetchedRemoteFiles = list
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
            }

            withContext(Dispatchers.Main) {
                val validFiles = fetchedRemoteFiles
                if (validFiles.isNullOrEmpty()) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                } else {
                    _uiState.update { state ->
                        state.copy(
                            isConnectingToSender = false,
                            enteredReceiveCode = sessionCode,
                            remoteHostIp = targetIp,
                            remoteHostPort = targetPort,
                            remoteSessionCode = sessionCode,
                            remoteChunkSizeBytes = remoteChunkSize,
                            pendingIncomingFiles = validFiles,
                            showReceiveConfirmationDialog = true,
                            currentScreen = AppScreen.RECEIVE,
                            statusBannerMessage = null
                        )
                    }
                }
            }
        }
    }

    fun confirmAndStartReceiving() {
        val incoming = _uiState.value.pendingIncomingFiles
        if (incoming.isEmpty()) {
            _uiState.update { it.copy(showReceiveConfirmationDialog = false) }
            return
        }
        _uiState.update { state ->
            state.copy(
                files = incoming,
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false
            )
        }
        startLiveChunkedTransfer(TransferDirection.RECEIVING)
    }

    fun cancelReceiveConfirmation() {
        _uiState.update { state ->
            state.copy(
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false,
                statusBannerMessage = "تم إلغاء استلام الملفات"
            )
        }
    }

    fun togglePauseResume() {
        _uiState.update { state ->
            val newPaused = !state.isPaused
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.PAUSED) {
                    f.copy(status = if (newPaused) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING)
                } else f
            }
            state.copy(
                isPaused = newPaused,
                files = updatedFiles,
                statusBannerMessage = if (newPaused) "تم إيقاف النقل مؤقتاً مع حفظ موضع الدفعة الحالية" else "تم استئناف النقل المباشر من آخر دفعة (Chunk)"
            )
        }
    }

    fun exportSelfApkToDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>()
            try {
                val sourceApk = File(appContext.applicationInfo.sourceDir)
                val outDir = resolveBarqSherDownloadsDir(appContext)
                val targetApk = File(outDir, "Barq-Sher.apk")
                sourceApk.inputStream().use { input ->
                    FileOutputStream(targetApk).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
                val sizeMb = String.format(Locale.US, "%.1f MB", targetApk.length() / (1024.0 * 1024.0))
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            statusBannerMessage = "تم حفظ ملف التطبيق Barq-Sher.apk ($sizeMb) في التنزيلات، وعبر الرابط: http://${state.networkStatus.localIp}:${state.networkStatus.port}/barq-p2p.apk"
                        )
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "رابط تنزيل الـ APK جاهز: http://${it.networkStatus.localIp}:${it.networkStatus.port}/barq-p2p.apk")
                    }
                }
            }
        }
    }

    private fun updateFileState(fileId: String, transform: (TransferFileItem) -> TransferFileItem) {
        _uiState.update { state ->
            state.copy(files = state.files.map { if (it.id == fileId) transform(it) else it })
        }
    }

    private fun computeQuickTag(name: String, size: Long): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest("$name:$size".toByteArray())
            digest.take(4).joinToString("") { "%02X".format(it) }
        } catch (_: Exception) {
            "5GHZ-OK"
        }
    }

    override fun onCleared() {
        super.onCleared()
        chunkServer?.stopServer()
    }
}
